AGENTPRESS PRO THEME
http://my.studiopress.com/themes/agentpress/

INSTALL
1. Upload the AgentPress Pro theme folder via FTP to your wp-content/themes/ directory. (The Genesis parent theme needs to be in the wp-content/themes/ directory as well.)
2. Go to your WordPress dashboard and select Appearance.
3. Activate the AgentPress Pro theme.
4. Inside your WordPress dashboard, go to Genesis > Theme Settings and configure them to your liking. To set up the theme like the demo, please visit http://my.studiopress.com/setup/agentpress-theme/.

WIDGET AREAS
Header Right - This is the widgeted area that appears after the title area section of the header.
Primary Sidebar - This is the primary sidebar if you are using the Content/Sidebar, Sidebar/Content, Content/Sidebar/Sidebar, Sidebar/Sidebar/Content or Sidebar/Content/Sidebar Site Layout option.
Secondary Sidebar - This is the secondary sidebar if you are using the Content/Sidebar/Sidebar, Sidebar/Sidebar/Content or Sidebar/Content/Sidebar Site Layout option.
Home - Featured - This is the featured section at the top of the homepage.
Home - Top - This is the top section of the content area on the homepage.
Home - Middle - 1 - This is first widget-area in the middle section of the content area on the homepage.
Home - Middle - 2 - This is second widget-area in the middle section of the content area on the homepage.
Home - Middle - 3 - This is third widget-area in the middle section of the content area on the homepage.
Home - Bottom - This is the bottom section of the content area on the homepage.
After Entry - This is the after entry section.
Listings Archive - This is the widget-area at the top of the listings archive.
Disclaimer - This is the disclaimer section of the footer section.
Footer 1 - This is the first column of the footer section.
Footer 2 - This is the second column of the footer section.
Footer 3 - This is the third column of the footer section.

FEATURED IMAGES
By default WordPress will create a default thumbnail image for each image you upload and the size can be specified in your dashboard under Settings > Media. In addition, the AgentPress Pro theme creates the following thumbnail images you'll see below, which are defined (and can be modified) in the functions.php file. These are the recommended thumbnail sizes that are used on the AgentPress Pro theme demo site.

properties - 500px by 500px

LOCALIZATION
The AgentPress Pro theme is translation ready.  More information about the translation process can be found here:http://codex.wordpress.org/Translating_WordPress/

SUPPORT
Please visit http://my.studiopress.com/help/ for theme support.

= 3.1 =
* Update theme setting defaults
* Use theme supports for after entry widget

= 3.1.1 =
* Relocate archive intro text on listing pages