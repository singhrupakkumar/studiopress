Genesis Portfolio Pro
=====================

This is a WordPress plugin designed to work on the Genesis theme framework. It adds a portfolio post type to Genesis child themes and provides HTML5 compatible template files with default CSS. 

The template files can be overridden by adding them to the child theme directory and the default portfolio image size can be overidden with an add_image_size function in the child theme functions.php file.
