<?php
/**
 * Property Search Results Loop Start
 *
 * @author 		PropertyHive
 * @package 	PropertyHive/Templates
 * @version     1.0.0
 */
?>
<ul class="properties clear">