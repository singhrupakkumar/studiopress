<?php
/**
 * Email Footer
 *
 * This template can be overridden by copying it to yourtheme/propertyhive/emails/email-footer.php.
 *
 * @author 		PropertyHive
 * @package 	PropertyHive/Templates/Emails
 * @version     1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

?>
																<table border="0" cellpadding="0" cellspacing="0" width="100%">
																	<tr>
																		<td style="text-align:center; font-size:11px;" class="text">
																			<?php if ( $unsubscribe_link != '' ) { ?><a href="<?php echo $unsubscribe_link; ?>">Unsubscribe</a><?php } ?>
																		</td>
																	</tr>
																</table>

															</div>
														</td>
													</tr>
												</table>
												<!-- End Content -->

											</td>
										</tr>
									</table>
									<!-- End Body -->
								</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</div>
	</body>
</html>