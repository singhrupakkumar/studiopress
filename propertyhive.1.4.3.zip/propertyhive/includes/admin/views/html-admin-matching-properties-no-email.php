<div class="wrap propertyhive">

	<h1>Properties Marked as Not Interested</h1>

	<div id="poststuff">

        <p><?php echo count($_POST['not_interested_property_id']); ?> properties marked as 'Not Interested' for this applicant.</p>
	
        <p class="submit">

            <a href="<?php echo get_edit_post_link($_GET['contact_id']); ?>" class="button-primary"><?php _e( 'Back To Contact', 'propertyhive' ); ?></a>

        </p>

    </div>

</div>