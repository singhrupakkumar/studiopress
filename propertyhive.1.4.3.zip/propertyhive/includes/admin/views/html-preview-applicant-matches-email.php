<?php
echo stripslashes($_POST['body']);
?>